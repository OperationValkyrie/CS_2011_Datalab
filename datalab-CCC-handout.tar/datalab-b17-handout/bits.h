


int bitXor(int, int);
int test_bitXor(int, int);
int tmax();
int test_tmax();
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int replaceByte(int, int, int);
int test_replaceByte(int, int, int);
int fitsBits(int, int);
int test_fitsBits(int, int);
int rotateLeft(int, int);
int test_rotateLeft(int, int);
int isPower2(int);
int test_isPower2(int);
int rempwr2(int, int);
int test_rempwr2(int, int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int bitParity(int);
int test_bitParity(int);
int greatestBitPos(int);
int test_greatestBitPos(int);
int logicalNeg(int);
int test_logicalNeg(int);
unsigned float_neg(unsigned);
unsigned test_float_neg(unsigned);
int float_f2i(unsigned);
int test_float_f2i(unsigned);
unsigned float_twice(unsigned);
unsigned test_float_twice(unsigned);
